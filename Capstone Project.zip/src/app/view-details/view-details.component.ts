import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormsModule } from '@angular/forms';
import { ViewDetailsService } from './view-details.service';
import { FlightBooking } from '../shared/FlightBooking';

@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrls: ['./view-details.component.css'],
  providers: [ViewDetailsService],
})
export class ViewDetailsComponent implements OnInit {
  flightDetails: FlightBooking[] = [];
  isDeleting = false;
  constructor(private viewDetailsService: ViewDetailsService) {}

  ngOnInit() {
    this.view();
  }
  view() {
    this.viewDetailsService.view().subscribe((respose) => {
      this.flightDetails = respose as [FlightBooking];
      
      console.log(respose);
      this.isDeleting = false;
    });
    return;
  }

  delete(id: number) {
    this.isDeleting = true;
    this.viewDetailsService.delete(id).subscribe((response) => {
      console.log(response);
      this.ngOnInit();
    });
    return;
  }
}
