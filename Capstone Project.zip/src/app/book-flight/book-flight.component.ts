import { Component, ElementRef, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormControl, NgForm } from '@angular/forms';
import { FlightBooking } from '../shared/FlightBooking';
import { BookFlightService } from './book-flight.service';

@Component({
  selector: 'app-book-flight',
  templateUrl: './book-flight.component.html',
  styleUrls: ['./book-flight.component.css'],
  providers: [BookFlightService],
})
export class BookFlightComponent implements OnInit {
  errorMessage: String = '';
  successMessage: String = '';
  submittingForm = false;

  constructor(
    private fb: FormBuilder,
    private bookFlightService: BookFlightService
  ) {}

  bookingForm = this.fb.group({
    passengerName: [],
    noOfTickets: [],
    flightId: [],
  });

  ngOnInit() {}

  // book() {
  //   // Code the method here

  // }
  book(form: NgForm) {
    if (!form.valid) {
      this.errorMessage = 'Some Error Occured. Please fill in correct values.';
      return;
    }
    this.submittingForm = true;
    let flightBooking = new FlightBooking();
    flightBooking.passengerName = form.value.passengerName;
    flightBooking.noOfTickets = form.value.numberOfTickers;
    flightBooking.flightId = form.value.flightId;

    let flightBookingObs = this.bookFlightService.getData(flightBooking);
    flightBookingObs.subscribe(
      (responseData) => {
        let data = responseData as { message: string };
        if (data.message.includes(':')) {
          this.successMessage = data.message;
        } else {
          this.errorMessage = data.message;
        }
        form.reset();
        this.submittingForm = false;
      },
      (error) => {
        this.errorMessage = error.message;
        this.submittingForm = false;
      }
    );
  }
}

function validateFlight(c: FormControl) {
  /* 
    Code the validator here
    Use flightError as the property
*/
}
